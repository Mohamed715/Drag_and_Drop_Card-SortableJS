# Drag & Drop Card
## [Watch it on youtube](https://youtu.be/9uyetVRYk8Q)
### Drag & Drop Card
Beautiful and simple drag and drop project using Html, Css and JavaScript using the library (SortableJS).

Don't forget to join the channel for more videos like this.
[Bedimcode](https://www.youtube.com/c/Bedimcode)
